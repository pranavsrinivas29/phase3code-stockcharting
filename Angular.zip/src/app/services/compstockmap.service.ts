import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Company } from '../models/Company';
import { Companystockmap } from '../models/Companystockmap';

@Injectable({
  providedIn: 'root',
})
export class CompstockmapService {
  url: string;

  constructor(private http: HttpClient, private router: Router) {
    this.url = 'http://localhost:8080/';
  }
  getAllMaps(): Observable<Companystockmap[]> {
    return this.http.get<Companystockmap[]>(this.url + 'getAllMappings');
  }
  getCompany(id: string): Observable<Company> {
    return this.http.get<Company>(this.url + id);
  }
  getCompanyStockMap(id: string): Observable<Companystockmap> {
    return this.http.get<Companystockmap>(this.url + id);
  }
  addMapping(value: Companystockmap) {
    this.http
      .post<Companystockmap>(this.url + 'mapcompanycode', value)
      .subscribe((responseData) => {
        console.log(responseData);
        this.router.navigate(['/comp-stock-map']);
      });
  }
  updateCompanyStockmap(companystockmap: Companystockmap) {
    this.http.put(this.url, companystockmap)
      .subscribe(response => {
        this.router.navigate(['/comp-stock-map']);
      });
  }
  getCompanyStocks(): Observable<Companystockmap[]> {
    return this.http.get<Companystockmap[]>(this.url);
  }
  deleteCompanyStockMap(companycode: string) {
    this.http.delete(this.url + companycode)
      .subscribe(response => {
        this.router.navigate(['/']);
      });
  }
  
}
