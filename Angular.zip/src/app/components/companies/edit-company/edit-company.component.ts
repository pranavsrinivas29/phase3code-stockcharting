import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import {Company} from '../../../models/company';
import { CompanyService } from '../../../services/company.service';
@Component({
  selector: 'app-edit-company',
  templateUrl: './edit-company.component.html',
  styleUrls: ['./edit-company.component.css']
})
export class EditCompanyComponent implements OnInit {
    company: Company = {
        id:2,
        name: '',
        
        turnover: '',
        ceo: '',
        boardOfDirectors: '',
        sectorname: '',
        companyBrief: ''
      };
     Id!:string;
  constructor(private companyService: CompanyService,  private route: ActivatedRoute) {
     this.route.params.subscribe(event => {
        this.Id = event.Id;

       });

    this.companyService.getCompany(this.Id).subscribe(x => this.company =x)

  }

 ngOnInit() {

     }
  onSubmit({value, valid}: NgForm) {
   this.companyService.updateCompany(this.company);
//       console.log(this.company);
   }
}
