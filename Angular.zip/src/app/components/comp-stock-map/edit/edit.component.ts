import { Component, OnInit } from '@angular/core';
import { CompStockMapComponent } from '../comp-stock-map.component';
import { CompstockmapService } from 'src/app/services/compstockmap.service';
import { NgForm } from '@angular/forms';
import { Companystockmap } from 'src/app/models/Companystockmap';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  CompstockmapService: any;
  f: any;
  companystockmap: Companystockmap = {
    id:2,
    companyname: '',
    
    
    companycode: '22',
    stockexchangename: ''
  
  };

  Id!:string;
  constructor(private companystockmapService: CompstockmapService,  private route: ActivatedRoute) {
     this.route.params.subscribe(event => {
        this.Id = event.Id;

       });
       this.companystockmapService.getCompanyStockMap(this.Id).subscribe(x => this.companystockmap =x)
      
      }

  ngOnInit() {}
  
  onsubmit({value, valid}: NgForm) {
    this.companystockmapService.updateCompanyStockmap(this.companystockmap);
 //       console.log(this.company);
    }
}  

