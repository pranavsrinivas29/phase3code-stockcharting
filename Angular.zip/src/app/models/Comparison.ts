export interface Comparison {
  companyname?: string;
  exchangename?: string;
  fromperiod?: string;
  toperiod?: string;
  periodicity?: string;
}
